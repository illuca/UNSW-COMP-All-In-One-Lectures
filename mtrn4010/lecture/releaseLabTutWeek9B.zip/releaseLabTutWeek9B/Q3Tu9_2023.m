
% Implementation, for solution of Question 3, Tutorial 9, MTRN4010
% Questions: You may ask the lecturer, j.guivant@unsw.edu.au


function Q3Tu9()
clc;

Lx=0.45;        % parameter Lx (as in Projects 1 and 2, but different value)
Xa = [3;5;0.45]; % actual car's pose

load('dataTu9Q1.mat');
% I add some noise, to simulate more realstic case.
Landmarks = data.Landmarks';
OOIs_LiCF=data.OOIs';

disp('OOIs_LCF'); disp(OOIs_LiCF');
disp('landmarks'); disp(Landmarks');





% initial guess, to optimizer.
PoseGuess0=Xa+[4;3;0.2];   % wrong by [4m,3m,0.2 radians]

% Initial guess.  Usually, we SHOULD propose a better one, not too far.

% from the solution; to reduce chances of getting trapped in a local minimum.
% Alternatively, we may use an optimizer better suited for nonconvex cost
% functions (e.g. a PSO based optimizer)

% If we used it in Project1.F, I would propose a better guessed pose, e.g.
% the last known pose, in recent times.


disp('Actual Pose (unknown to us)'); disp(Xa');
PoseS = EstimateLidarPoseAndLx(PoseGuess0,OOIs_LiCF,Landmarks);
% show solution.
disp('solution (estimated Pose)'); disp(PoseS');


figure(1); clf();

% convert OOIs to GCF using estimated pose.
OOIs_GCF2 = TransformCF01(PoseS,Lx,OOIs_LiCF); 
plot(Xa(1),Xa(2),'og');
hold on;
plot(PoseS(1),PoseS(2),'+m');

plot(Landmarks(1,:),Landmarks(2,:),'b*'); 
plot(OOIs_GCF2(1,:),OOIs_GCF2(2,:),'ro');

legend({'Actual Position', 'Estimated position','Landmarks in GCF','OOIs in GCF (Estimated)'}); 


end

%...................................................
function PoseS = EstimateLidarPoseAndLx(PoseGuess0,OOIs_LiCF,Landmarks)

Op=optimset('TolFun',0.01);
tic();
[PoseS,fval,exitflag] = fminsearch(@(X) CostA(X,OOIs_LiCF,Landmarks), PoseGuess0,Op);  %Solution
dt=toc()*1000

end
%...................................................

% Cost function, based on positions.
function c=CostA(poseV,OOIs_LCF,Landmarks)
% PoseV:  proposed vehicle's pose.
% parameters 
%OOIs_LCF:      Positions of detected OOIs, in Lidar's CF.
%Landmarks:     Positions of associated Landmarks in GCF.

%Express OOIs' positions in GCF, based on proposed LiDAR pose.
Lx=0.45;
OOIs_GCF = TransformCF01(poseV,Lx,OOIs_LCF);  

% evaluate discrepancy between Landmarks positions and those of the 
% proposed ones of OOIs in GCF.
d= Landmarks -OOIs_GCF;
d = (d.*d); d=sqrt(d(1,:)+d(2,:));    
c=sum(d);               
end

%...........................................
% Auxiliary function
function pp =  TransformCF01(X,Lx,pp)  
h=X(3);
c=cos(h); s=sin(h);
R= [ [ c,-s];[s,c]];
pp=R*pp;
T = [Lx;0];
T = X(1:2)+R*T;
pp(1,:)=pp(1,:)+T(1);
pp(2,:)=pp(2,:)+T(2);
end
%...........................................



