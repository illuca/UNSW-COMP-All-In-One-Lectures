function UsingDataTutorial01()

% Simple program. It reads LiDAR scans (from some of the provided files), and plot them, in the LiDAR's coordinate frame.    
% contact the lecturer, if you have doubts. (j.guivant@unsw.edu.au)

%   data files:
    file1 = 'LiDAR_points_001.mat';
    file2 = 'LiDAR_points_003.mat';
    file3 = 'LiDAR_points_004.mat';
    

    

% read files, 
% Here, each scan, in cartesian representation, it its local CF.
load(file1);         pxy1=dataScanXY.pxy;      poseLidar1=dataScanXY.X;
load(file2);         pxy2=dataScanXY.pxy;      poseLidar2=dataScanXY.X;
load(file3);         pxy3=dataScanXY.pxy;      poseLidar3=dataScanXY.X;
clear dataScanXY;
% ................................................

% useful fields:
% .pxy    : array of 2D points, stored in a matrix 2xN, being pxy(:,k) the point #k.  Units=(m;m) 
% .X      : pose from which the scan was taken. pose=[x;y;heading]. Units=(m;m;radians) 
% .info   : string which gives brief details.
% .ranges : native range data (not used in week1's problems)


% plot the scans.
figure(1); clf();
%subplot(211); 
plot(-pxy1(2,:),pxy1(1,:),'b.'); axis equal;
title('All scans, locally expressed'); 
xlabel('Y(Left/Right)'); ylabel('X(ahead)');

hold on;  plot(-pxy2(2,:),pxy2(1,:),'r.'); 
hold on;  plot(-pxy3(2,:),pxy3(1,:),'g.'); 
axis equal; hold off;
legend({'scan A','scan B','scan C'});

 



% here, we need to rotate and translate those points (according to the
% LiDAR's pose), and jointly plot them in a figure.
% You will see that the three scans will appear aligned / matched.

end

% -------------------------------------------------------

