# Specify the value of W, W_1base, W_2base
param W = 6; 
param W_1base = 2.8; # 0 for Part (b). 2.8 for Part (d)
param W_2base = 2.8; # 0 for Part (b). 2.8 for Part (d)

# Specify the variables for optimisation 
var R;
var W_1 >= W_1base;
var W_2 >= W_2base;
minimize time: R;
subject to R_1: R >= 3 + 5*W_1;
subject to R_2: R >= 1 + 7*W_2;
subject to W_sum: W_1 + W_2 = W;

