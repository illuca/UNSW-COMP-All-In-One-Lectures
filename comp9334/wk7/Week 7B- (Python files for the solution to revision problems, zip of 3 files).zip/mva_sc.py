#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 Function for Mean Value Analysis (MVA)

"""

import numpy as np 

def mva_sc(S,V,N,Z = 0):

    # MVA for closed single-class queueing networks 
    #
    # Inputs: 
    #   S = service time per visit (a 1-D array)
    #   V = visit ratio (a 1-D array)
    #   N = Number of terminals or number of users  
    #   Z = thinking time
    #       If Z is not provided, its default value is 0.
    # 
    # Outputs:
    #   R = response time per visit ((N+1)-by-K array)
    #   nbar = mean queue length ((N+1)-by-K array)
    #   Rzero = system response time (1-D (N+1) array)
    #   Xzero = system throughput (1-D (N+1) array)
    #   U = utilisation ((N+1)-by-K array)
    #
    # Rzero[i] = System response time when there are i users
    # Xzero[i] = System throughput when there are i users 
       
    # Initialisation
    K = len(V)  # number of devices
       
    # Storage
    nbar = np.zeros((N+1,K))
    R = np.zeros((N+1,K))
    X = np.zeros((N+1,K))
    Rzero = np.zeros((N+1,))
    Xzero = np.zeros((N+1,))
    U = np.zeros((N+1,K))
    
    for n in range(1,N+1):  # For each customers
        R[n,:] = S * (1 + nbar[n-1,:])
        Rzero[n] = np.sum(V * R[n,:])
        Xzero[n] = n / (Rzero[n] + Z)
        X[n,:] = Xzero[n] * V
        U[n,:] = S * X[n,:]
        nbar[n,:] = X[n,:] * R[n,:]        
   
    
    return R,X,nbar,Rzero,Xzero,U