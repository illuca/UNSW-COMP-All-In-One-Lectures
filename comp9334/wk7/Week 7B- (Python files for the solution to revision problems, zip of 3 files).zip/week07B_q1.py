#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 

Revision problem, week 7B, Q1 (Solution)
"""

import numpy as np
import matplotlib.pyplot as plt
import mva_sc 

# %% Set up the problem 

# Device 1 = CPU
# Device 2 = Disk 1
# Device 3 = Disk 2
# Device 4 = Disk 3   
T = 60*60     # Measurement time 
U1 = 0.75     # Utilisation 
U2 = 0.5
U3 = 0.5
U4 = 0.25
C = 36000

# Compute the service demands and put it into a numpy 1-D array
X0 = C/T
D = np.array([U1/X0,U2/X0,U3/X0,U4/X0])

# The visit ratios are 1
V = np.ones((4,))

# Thinking time 
Z = 7 

# %% Call MVA 
# MVA for 1 to 200 users
Nmax = 200
R,X,nbar,Rzero,Xn,U = mva_sc.mva_sc(D,V,Nmax,Z)

# Asymptotic bound
Xbound = np.minimum( np.arange(Nmax+1)/(sum(D)+Z), 1/max(D))

# plot the graph

plt.figure()
plt.plot(np.arange(Nmax+1),Xn,'b-',label='MVA')
plt.plot(np.arange(Nmax+1),Xbound,'r-',label='Bound')
plt.legend()
plt.xlabel('Number of terminals')
plt.ylabel('System throughput')
#plt.savefig('fig/week07B_q1_tp.pdf')

# %% Find the speed up factor for CPU
scaling_factors_array = np.linspace(1,2,num=11)
mrt_new = np.zeros_like(scaling_factors_array)
N = 70 

for i in range(len(scaling_factors_array)):
    sf = scaling_factors_array[i]
    Dnew = np.copy(D)
    Dnew[0] = Dnew[0] / sf 
    R,X,nbar,Rzero,Xn,U = mva_sc.mva_sc(Dnew,V,N,Z)
    mrt_new[i] = Rzero[-1]
  
plt.figure()    
plt.plot(scaling_factors_array,mrt_new,'b-',label='response time')
plt.hlines(0.3, 1, 2,label='target respons time')
plt.legend()
plt.grid()
plt.xlabel('Speeding up factor for CPU')
plt.ylabel('Response time')
#plt.savefig('fig/week07B_q1_rt.pdf') 
    
    
