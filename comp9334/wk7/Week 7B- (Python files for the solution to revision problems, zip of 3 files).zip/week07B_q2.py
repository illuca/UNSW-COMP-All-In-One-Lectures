#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 

Revision problem, week 7B, Q2 (Solution to Part b)
"""

import numpy as np
import mva_sc 

# %% Set up the problem 

C = 10800       # Number of completed HTTP requests 
T = 3600        # Observation time in seconds 
U_CPU = 0.3     # CPU utilisation
S_disk = 0.02   # Service time of disk in seconds 
V_disk = 3      # Visit ratio of the disk 
num_devices = 2 # Two device: CPU and disk 
Z = 0           # Thinking time 
N_max = 3       # Maximum number of users

# Service demand (D) of the CPU
X0 = C / T    # System throughput
D_CPU = U_CPU / X0

# Service demand of the disk
D_disk = V_disk * S_disk 

# Put the service demands in a numpy 1-D array
# Device 1 = CPU
# Device 2 = Disk 1
D = np.array([D_CPU, D_disk])

# The visit ratios are 1
V = np.ones((num_devices,))

# %% Call MVA 
# MVA for 0 to 3 users
R, X, nbar, R_zero, X_zero, U = mva_sc.mva_sc(D,V,N_max,Z)

print('The throughput X_0(n) for n = 0, 1, 2, 3 (to 2 demcimal places)')
for n in range(4):
    print(f'X_0({n}) = {X_zero[n]:.2f}')