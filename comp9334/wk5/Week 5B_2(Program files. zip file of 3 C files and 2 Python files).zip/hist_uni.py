#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 Week 4B, Lecture 

Generate exponentially distributed random numbers 


"""

import numpy as np 
import matplotlib.pyplot as plt 

# Generate 10,000 random numbers that are uniformly distributed
# distributed in (0,1)
n = 10000
u = np.random.random((n,))

# To check the numbers are really uniform distributed
# Plot an histogram of the number 
nb = 50 # Number of bins in histogram 
freq, bin_edges = np.histogram(u, bins = nb, range=(0,1))

# Lower and upper limits of the bins
bin_lower = bin_edges[:-1]
bin_upper = bin_edges[1:]
# expected number of uniformly distributed numbers in each bin
y_expected = n/nb

bin_center = (bin_lower+bin_upper)/2
bin_width = bin_edges[1]-bin_edges[0]

plt.bar(bin_center,freq,width=bin_width)
plt.hlines(y_expected,0,1,colors='r',label = 'Expected',Linewidth =3)
plt.legend(loc='lower left')
plt.title('Histogram of 10^4 uniformly distributed psuedo-random numbers')
plt.savefig('hist_uni.png')

