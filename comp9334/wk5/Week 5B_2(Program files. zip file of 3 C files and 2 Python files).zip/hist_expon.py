#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 Week 4B, Lecture 

Generate exponentially distributed random numbers 


"""

import numpy as np 
import matplotlib.pyplot as plt 

# Generate 10,000 random numbers that are uniformly
# distributed in (0,1)
n = 10000
u = np.random.random((n,))

# To produce 10,000 numbers that are exponentially distributed
# using inverse transformation method
# If u is uniformly distributed 
# Then x = -log(1-u)/lamb is exponentially distributed with rate lamb
lamb = 2
x = -np.log(1-u)/lamb

# To check the numbers are really exponentially distributed
# Plot an histogram of the number 
nb = 50 # Number of bins in histogram 
freq, bin_edges = np.histogram(x, bins = nb, range=(0,np.max(x)))

# Lower and upper limits of the bins
bin_lower = bin_edges[:-1]
bin_upper = bin_edges[1:]
# expected number of exponentially distributed numbers in each bin
y_expected = n*(np.exp(-lamb*bin_lower)-np.exp(-lamb*bin_upper))

bin_center = (bin_lower+bin_upper)/2
bin_width = bin_edges[1]-bin_edges[0]

plt.bar(bin_center,freq,width=bin_width)
plt.plot(bin_center,y_expected,'r--',label = 'Expected',Linewidth =3)
plt.legend()
plt.title('Histogram of 10^4 exponentially distributed psuedo-random numbers')
plt.savefig('hist_expon.png')

