#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 Week05A Revision Problem Question 2 Parts a and b 

This file is modified from comp_confidence_interval.py
from Week 05A's lecture
"""

# import 
import numpy as np
from scipy import stats

# %% Problem parameters 
# mean response times from 6 independent replications 
mrt = np.array([4.56, 5.23, 5.12, 6.15, 5.57, 5.34])

# Part (a) of the question asked for 95% confidence interval
# while part (b) asks for 90% 
# Work out the correponding alpha values and put them in a dictionary
alpha_dict = {'Part a': 0.05, 'Part b': 0.10}

# %% Solution 

# Number of tests
n = len(mrt) 

# Calculate mean and sample standard deviation  
mean_mrt = np.mean(mrt)
std_mrt = np.std(mrt, ddof=1)  # SEE NOTES AT THE END OF THE FILE

# Compute the confidence interval for Parts (a) and (b)
for question_part in alpha_dict.keys():  
    # Fetch the alpha value for the part of the question 
    alpha = alpha_dict[question_part]

    # Compute the required multiplication factor mf 
    # and compute the confidence interval
    mf = stats.t.ppf(1-alpha/2,n-1) / np.sqrt(n)
    confidence_interval = mean_mrt + np.array([-1,1]) * mf * std_mrt

    print(question_part, 'confidence interval:',confidence_interval)

# %% Notes:
#    
# If you use the numpy library to calculate sample standard deviation,
# you need to use include the option on ddof, i.e. you need to write
# 
# np.std(mrt, ddof=1)
#
# for the example above. 
# 
# If you use the default, np.std(mrt) divides by sample size, 
# not (sample size - 1)
# 
# np.std(mrt) <--- this is incorrect 
#
# If you use the scipy.stats library to calculate sample standard deviation,
# you need to write
#
# stats.tstd(mrt) <-- correct command 
# 
# for the example above.     




