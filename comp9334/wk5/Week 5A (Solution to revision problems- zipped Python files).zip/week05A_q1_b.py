#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 Capacity Planning 

Revision Problem Week 5B, Q1, Part (b): Transient removal 
"""

import numpy as np 
import matplotlib.pyplot as plt 

# Put the traces in a numpy array
nsim = 5     # number of simulation
ndp = 20000  # number of data points in each simulation
response_time_traces = np.zeros((nsim,ndp))

# load the traces 
for i in range(5):
    response_time_traces[i,:] = np.loadtxt('trace'+str(i+1))
        
# Drop the first 100 points as the transient
# Compute the mean from data points 1001 to 20,000
mt = np.mean(response_time_traces[:,1000:],axis=1)

# Find the mean and standard deviation of mt
mean_of_all_simulations = np.mean(mt)
std_of_all_simulations = np.std(mt, ddof=1)    